import { NextResponse } from 'next/server';
import nacl from 'tweetnacl';
import { PublicKey } from '@solana/web3.js';

export async function POST(req: Request) {
  try {
    const { message, signature, pubkey } = await req.json();
    const msg = new Uint8Array(message);
    const sig = new Uint8Array(signature);
    const pk = new PublicKey(pubkey);
    const valid = nacl.sign.detached.verify(msg, sig, pk.toBytes());
    return NextResponse.json({ valid });
  } catch (e:any) {
    return NextResponse.json({ valid: false, error: e.message }, { status: 400 });
  }
}
