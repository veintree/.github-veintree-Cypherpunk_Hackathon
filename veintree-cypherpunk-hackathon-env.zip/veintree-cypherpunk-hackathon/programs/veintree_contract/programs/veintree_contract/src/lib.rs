//! FR: Contrat Veintree POC — multi-utilisateurs + index de preuves (max 10).
//! EN: Veintree POC — multi-user + proof index (max 10).

use anchor_lang::prelude::*;

declare_id!("VeinTree1111111111111111111111111111111111");

const MAX_PROOFS: usize = 10;

#[program]
pub mod veintree_contract {
    use super::*;

    /// FR: Enregistre le hash de preuve pour l'utilisateur (PDA par wallet).
    /// EN: Registers user's proof hash (PDA per wallet).
    pub fn register_proof(ctx: Context<RegisterProof>, proof_hash: [u8; 32]) -> Result<()> {
        let state = &mut ctx.accounts.state;
        state.last_proof = proof_hash;
        Ok(())
    }

    /// FR: Enregistre et indexe la preuve (ajoute au UserIndex si place).
    /// EN: Registers and indexes the proof (append to UserIndex if space).
    pub fn register_proof_and_index(ctx: Context<RegisterWithIndex>, proof_hash: [u8; 32]) -> Result<()> {
        let state = &mut ctx.accounts.state;
        state.last_proof = proof_hash;

        let index = &mut ctx.accounts.index;
        if (index.count as usize) < MAX_PROOFS {
            index.proofs[index.count as usize] = proof_hash;
            index.count = index.count.saturating_add(1);
        }
        Ok(())
    }
}

#[derive(Accounts)]
#[instruction(proof_hash: [u8; 32])]
pub struct RegisterProof<'info> {
    #[account(
        init_if_needed,
        payer = payer,
        space = 8 + 32,
        seeds = [b"state", payer.key().as_ref()],
        bump
    )]
    pub state: Account<'info, State>,

    #[account(mut)]
    pub payer: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(proof_hash: [u8; 32])]
pub struct RegisterWithIndex<'info> {
    #[account(
        init_if_needed,
        payer = payer,
        space = 8 + 32,
        seeds = [b"state", payer.key().as_ref()],
        bump
    )]
    pub state: Account<'info, State>,

    #[account(
        init_if_needed,
        payer = payer,
        space = 8 + 1 + (32 * MAX_PROOFS),
        seeds = [b"index", payer.key().as_ref()],
        bump
    )]
    pub index: Account<'info, UserIndex>,

    #[account(mut)]
    pub payer: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[account]
pub struct State {
    pub last_proof: [u8; 32],
}

#[account]
pub struct UserIndex {
    pub count: u8,
    pub proofs: [[u8; 32]; MAX_PROOFS],
}
