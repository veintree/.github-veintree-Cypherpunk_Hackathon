import { describe, it, expect } from 'vitest';
import { toProofHash, getUserStatePda, verifySignature } from '../src';
import { Keypair, PublicKey } from '@solana/web3.js';
import nacl from 'tweetnacl';

describe('SDK basics', () => {
  it('toProofHash is deterministic and 32 bytes', () => {
    const a = toProofHash('hello');
    const b = toProofHash(new TextEncoder().encode('hello'));
    expect(a.length).toBe(32);
    expect(Buffer.from(a).toString('hex')).toBe(Buffer.from(b).toString('hex'));
  });

  it('PDA derivation is stable', () => {
    const kp = Keypair.generate();
    const [pda1] = getUserStatePda(kp.publicKey);
    const [pda2] = getUserStatePda(new PublicKey(kp.publicKey.toBytes()));
    expect(pda1.toBase58()).toBe(pda2.toBase58());
  });

  it('verifySignature succeeds for valid Ed25519 signature', () => {
    const kp = nacl.sign.keyPair();
    const msg = new TextEncoder().encode('veintree');
    const sig = nacl.sign.detached(msg, kp.secretKey);
    const ok = verifySignature(msg, sig, new PublicKey(kp.publicKey));
    expect(ok).toBe(true);
  });
});
