#!/usr/bin/env bash
set -euo pipefail

# Creates a GitHub Projects (v2) board with default views and fields.
# Requirements:
# - gh CLI (https://cli.github.com/)
# - gh auth login
# - OWNER env var set to your org/user (e.g., export OWNER=veintree)
#
# Usage:
#   OWNER=veintree scripts/create-project-board.sh "Veintree Hackathon Board"

if [[ -z "${OWNER:-}" ]]; then
  echo "Set OWNER env var to your org/user (e.g., export OWNER=veintree)"
  exit 1
fi

NAME="${1:-Veintree Hackathon Board}"
echo "Creating project: $NAME (owner=$OWNER)"
PROJECT_JSON=$(gh project create --owner "$OWNER" --title "$NAME" --format json)
PROJECT_NUMBER=$(echo "$PROJECT_JSON" | jq -r '.number')

echo "Project created: number=$PROJECT_NUMBER"
echo "Save this number for scripts: export PROJECT_NUMBER=${PROJECT_NUMBER}"

# Create fields
create_field() {
  local field_title="$1"; local field_type="$2"; local options_json="${3:-[]}"
  gh project field-create --owner "$OWNER" --number "$PROJECT_NUMBER"     --name "$field_title" --data-type "$field_type"     ${options_json:+--single-select-options "$options_json"} >/dev/null
}

# Single-select options require a JSON array of strings
STATUS_OPTS='["Todo","In progress","Review","Done"]'
PRIORITY_OPTS='["Must","Should","Could","Post"]'
TYPE_OPTS='["program","sdk","app","security","ci-cd","scripts"]'

create_field "Status" "SINGLE_SELECT" "$STATUS_OPTS"
create_field "Priority" "SINGLE_SELECT" "$PRIORITY_OPTS"
create_field "Type" "SINGLE_SELECT" "$TYPE_OPTS"

# Create a board view grouped by Status
gh project view --owner "$OWNER" --number "$PROJECT_NUMBER" >/dev/null
echo "Project fields created. Add issues then group by Status in the UI."

echo "Tip:"
echo "  export PROJECT_NUMBER=${PROJECT_NUMBER}"
echo "  ./scripts/create-issues.sh"
