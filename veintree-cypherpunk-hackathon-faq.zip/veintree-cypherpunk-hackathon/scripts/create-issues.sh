#!/usr/bin/env bash
set -euo pipefail

# Creates all Veintree hackathon issues using GitHub CLI (gh).
# Requirements:
#   - gh installed: https://cli.github.com/
#   - gh auth login
#   - Run from repo root (where .git exists)
#
# Optional: also add issues to a GitHub Project board.
#   Set OWNER and PROJECT_NUMBER env vars, e.g.:
#     export OWNER="veintree"
#     export PROJECT_NUMBER="1"
#   The script will then add each created issue to that project.
#
# Labels will be created if they don't exist.

# ---------- helpers ----------
need_cmd() { command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1"; exit 1; }; }
ensure_label() {
  local name="$1"; local color="$2"; local desc="${3:-}"
  if ! gh label list --limit 200 | awk '{print $1}' | grep -qx "$name"; then
    gh label create "$name" --color "$color" --description "$desc" || true
  fi
}
add_to_project_if_set() {
  local issue_url="$1"
  if [[ -n "${OWNER:-}" && -n "${PROJECT_NUMBER:-}" ]]; then
    gh project item-add --owner "$OWNER" --number "$PROJECT_NUMBER" --url "$issue_url" >/dev/null || true
  fi
}

need_cmd gh
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "Run this from the repo root."; exit 1; }

# ---------- labels ----------
ensure_label "must-have" "d73a4a" "MVP for hackathon"
ensure_label "should-have" "fbca04" "Important for hackathon"
ensure_label "could-have" "0e8a16" "Optional for hackathon"
ensure_label "post-hackathon" "c5def5" "Planned after hackathon"
ensure_label "program" "1d76db" "On-chain program (Rust/Anchor)"
ensure_label "sdk" "5319e7" "SDK (TS/Rust)"
ensure_label "app" "0e8a16" "Client app (Next.js)"
ensure_label "security" "b60205" "Security/Crypto"
ensure_label "ci-cd" "0052cc" "CI/CD & Deploy"
ensure_label "scripts" "5319e7" "Tooling & Scripts"
ensure_label "good-first-issue" "7057ff" "Starter task"

# ---------- issues ----------
create_issue() {
  local title="$1"; local body="$2"; local labels="$3"
  echo "Creating issue: $title"
  url=$(gh issue create --title "$title" --body "$body" --label "$labels" --json url -q .url)
  echo " -> $url"
  add_to_project_if_set "$url"
}

# Must have
create_issue "[Program] Implement register_proof & verify_proof instructions" "**FR**: Implémenter les deux instructions de base (Rust/Anchor) pour écrire et vérifier un hash de preuve on-chain.
**EN**: Implement core instructions to write and verify a proof hash on-chain." "must-have,program,good-first-issue"

create_issue "[SDK] Add proof hash & transaction helpers (TS & Rust)" "**FR**: Fonctions de hash & wrappers pour appeler le programme Solana.
**EN**: Hash helpers & wrappers to call the on-chain program." "must-have,sdk,good-first-issue"

create_issue "[App] Minimal bilingual demo (register & verify proof)" "**FR**: UI Next.js simple pour enregistrer une preuve et vérifier son statut.
**EN**: Simple Next.js UI to register a proof and verify status." "must-have,app"

create_issue "[Mock] Simulate vein scan → proof hash" "**FR**: Simuler un scan de veines générant un hash stable.
**EN**: Simulate a vein scan producing a stable hash." "must-have,sdk,app"

create_issue "[Security] Integrate SHA3/Blake2 hashing + Ed25519 signatures" "**FR**: Ajouter hashing fort + signer les messages côté client.
**EN**: Add strong hashing + client-side signing." "must-have,security"

# Should have
create_issue "[Program] Multi-user PDAs & mapping account → proofs" "**FR**: Support multi-utilisateur via PDA par wallet & index minimal.
**EN**: Multi-user via PDA per wallet & minimal index." "should-have,program"

create_issue "[Scripts] Devnet deploy & airdrop init" "**FR**: Script d'initialisation (clé, airdrop, build, deploy).
**EN**: Initialization script (key, airdrop, build, deploy)." "should-have,scripts"

create_issue "[CI/CD] Build, lint, test + deploy app" "**FR**: Activer pipelines CI pour Rust/TS + déploiement Vercel/Cloudflare.
**EN**: CI pipelines for Rust/TS + Vercel/Cloudflare deployment." "should-have,ci-cd"

# Could have
create_issue "[Liveness] Basic challenge-response" "**FR**: Défi simple (timestamp/random) et validation.
**EN**: Simple challenge (timestamp/random) and validation." "could-have,security,sdk,app"

create_issue "[App] QR code sharing for verification" "**FR**: Partage d'une preuve via QR pour vérification cross-device.
**EN**: Share proof via QR for cross-device verification." "could-have,app"

create_issue "[Integration] Wallet connection (Phantom/Solana CLI)" "**FR**: Connexion wallet pour signer les transactions.
**EN**: Wallet connection to sign transactions." "could-have,app,sdk"

# Post-hackathon
create_issue "[Hardware] FPGA dongle integration" "**FR**: Intégration matérielle du dongle FPGA Veintree.
**EN**: Hardware integration of the Veintree FPGA dongle." "post-hackathon,program,sdk"

create_issue "[ZK] zk-SNARK proof of biometrics" "**FR**: Preuve Zero-Knowledge pour la biométrie (concept/proto).
**EN**: Zero-Knowledge proof for biometrics (concept/proto)." "post-hackathon,security"

create_issue "[Use cases] EUDI Wallet & healthcare flows" "**FR**: Parcours régulés (EUDI, santé, essais cliniques).
**EN**: Regulated user journeys (EUDI, healthcare, clinical)." "post-hackathon,app,sdk,program"

echo "All issues created. Optionally set OWNER/PROJECT_NUMBER to auto-add to a Project board."
