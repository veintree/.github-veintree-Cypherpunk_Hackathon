# ❓ FAQ — Veintree Hackathon

## Wallet / App
**Phantom not detected**
- Installe Phantom (Chrome/Brave) et active le site.
- Dev: http://localhost:3000 doit utiliser **https** si votre navigateur/extension l’exige (désactivez l’option “Block insecure” si besoin).

**Wallet connected but transactions fail**
- Assure-toi d’être sur **devnet** dans Phantom.
- Airdrop du wallet: `solana airdrop 2` (devnet).
- Vérifie les logs du navigateur.

**Signature impossible (`signMessage` undefined)**
- Active “Experimental: Sign messages” dans Phantom si nécessaire.

## Program / On-chain
**Program ID mismatch**
- Après `anchor deploy`, remplace `PROGRAM_ID` dans `sdk/ts/src/veintree-sdk.ts` par l’ID déployé.
- Regénère le build SDK: `npm run build` (dans `sdk/ts`).

**`Account not found` / `State PDA missing`**
- L’instruction `register_*` crée les comptes si besoin. Si l’erreur persiste: airdrop le payer, redeploy, réessaie.
- Vérifie que tu appelles `register_*` avant `verify`/`list`.

**`Transaction simulation failed` / `insufficient funds`**
- Airdrop: `solana airdrop 2` (répéter si besoin).  
- Confirme le cluster: `solana config get` doit pointer vers devnet.

**`Anchor version mismatch`**
- Utilise Anchor CLI `v0.30.1`. `anchor --version` doit afficher `0.30.1`.
- Si Docker: rebuild `docker compose build veintree-dev`.

**Solana CLI incompatible**
- Pin: `sh -c "$(curl -sSfL https://release.solana.com/stable/install)"` puis `solana --version`.
- En Docker, l’image inclut la version stable par défaut.

## SDK / TypeScript
**`Cannot find module .../idl/veintree_contract.json`**
- Chemin manquant? L’IDL est dans `sdk/ts/src/idl/veintree_contract.json`.
- Rebuild: `npm run build` (dans `sdk/ts`).

**ESM/CJS errors (`ERR_REQUIRE_ESM`)**
- Le SDK est **ESM**. Vérifie `"type": "module"`.
- Utilise `import ... from` plutôt que `require()`.

**SHA3 hashing differences**
- Nous utilisons `@noble/hashes/sha3`. Hash = 32 octets (SHA3-256).
- Si tu changes d’algo (BLAKE2, etc.), aligne **SDK** et **verifications**.

## App / Next.js
**Env vars non lues**
- Copie `app/.env.example` → `app/.env`.  
- Variables clés: `NEXT_PUBLIC_SOLANA_CLUSTER`, `NEXT_PUBLIC_SOLANA_RPC_URL`.
- Redémarre `npm run dev` après changement d’ENV.

**CORS / API route `/api/verify`**
- En local, Next.js gère le même host → pas de CORS.  
- En prod (domaine distinct), configure CORS si tu appelles depuis une autre origine.

**Build prod échoue**
- Build SDK d’abord (Dockerfile.prod le fait).  
- Vérifie les versions Node (nous pinons Node 20).

## Docker
**`anchor` / `solana` introuvables**
- Utilise le service **veintree-dev** (`docker compose run --rm veintree-dev bash`).  
- Vérifie le PATH: `solana --version`, `anchor --version`.

**Port 3000 déjà utilisé**
- Stoppe les autres services Next (`lsof -i :3000`).  
- Ou change le port dans `docker-compose.yml`.

## Scripts
**Airdrop rate limited**
- Attends quelques minutes, ou airdrop par petits montants (ex: 1 SOL).

**`gh` CLI errors (issues/projects)**
- `gh auth login` puis relance les scripts dans `scripts/`.
- Vérifie OWNER/PROJECT_NUMBER pour `create-issues.sh`.

## Windows / WSL
- Utilise **WSL2** (Ubuntu) pour Solana/Anchor.  
- Monte le projet dans le FS Linux (`/home/...`), pas dans `/mnt/c/...` pour éviter les lenteurs.

## Bonnes pratiques
- Toujours vérifier le **cluster** et l’**ID programme** avant de débugguer la logique.  
- Petites PR, test rapide, logs explicites.  
- Aucune donnée biométrique brute n’est stockée — seulement des **hashes**.

---

### Besoin d’aide ?
Ouvre une issue avec label `help wanted`, ou viens sur Discord `#veintree-hackathon`.
