import { Connection, PublicKey } from "@solana/web3.js";
import * as anchor from "@coral-xyz/anchor";
import { sha3_256 } from "@noble/hashes/sha3";
import nacl from "tweetnacl";
import idl from "./idl/veintree_contract.json";

export const PROGRAM_ID = new PublicKey("VeinTree1111111111111111111111111111111111");
const STATE_SEED = "state";
const INDEX_SEED = "index";

export function getUserStatePda(user: PublicKey): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from(STATE_SEED), user.toBuffer()], PROGRAM_ID);
}
export function getUserIndexPda(user: PublicKey): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from(INDEX_SEED), user.toBuffer()], PROGRAM_ID);
}

export function toProofHash(input: Uint8Array | string): Uint8Array {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  return new Uint8Array(sha3_256(bytes));
}

export function makeChallenge(): Uint8Array {
  const nonce = crypto.getRandomValues(new Uint8Array(16));
  const ts = new TextEncoder().encode(Date.now().toString());
  const payload = new Uint8Array(nonce.length + ts.length);
  payload.set(nonce, 0); payload.set(ts, nonce.length);
  return payload;
}

export function getProgram(connection: Connection, wallet: anchor.Wallet) {
  const provider = new anchor.AnchorProvider(connection, wallet, { commitment: "confirmed" });
  return new anchor.Program(idl as anchor.Idl, PROGRAM_ID, provider);
}

export async function registerProof(connection: Connection, wallet: anchor.Wallet, proofHash: Uint8Array) {
  const program = getProgram(connection, wallet);
  const [state] = getUserStatePda(wallet.publicKey);
  await program.methods
    .registerProof([...proofHash] as any)
    .accounts({ state, payer: wallet.publicKey, systemProgram: anchor.web3.SystemProgram.programId })
    .rpc();
  return state;
}

export async function registerProofAndIndex(connection: Connection, wallet: anchor.Wallet, proofHash: Uint8Array) {
  const program = getProgram(connection, wallet);
  const [state] = getUserStatePda(wallet.publicKey);
  const [index] = getUserIndexPda(wallet.publicKey);
  await program.methods
    .registerProofAndIndex([...proofHash] as any)
    .accounts({ state, index, payer: wallet.publicKey, systemProgram: anchor.web3.SystemProgram.programId })
    .rpc();
  return { state, index };
}

export async function verifyProof(connection: Connection, user: PublicKey, proofHash: Uint8Array) {
  const [state] = getUserStatePda(user);
  const accountInfo = await connection.getAccountInfo(state);
  if (!accountInfo) return { exists: false, matches: false };
  const data = accountInfo.data;
  if (data.length < 8 + 32) return { exists: true, matches: false };
  const stored = data.slice(8, 8 + 32);
  const matches = stored.every((b, i) => b === proofHash[i]);
  return { exists: true, matches };
}

// FR: Lit l'index utilisateur et renvoie un tableau de hashes (0..count).
// EN: Reads the user index and returns an array of proof hashes (0..count).
export async function listProofs(connection: Connection, user: PublicKey): Promise<Uint8Array[]> {
  const [index] = getUserIndexPda(user);
  const info = await connection.getAccountInfo(index);
  if (!info) return [];
  const data = info.data;
  if (data.length < 8 + 1) return [];
  const count = data[8]; // first byte after discriminator
  const proofs: Uint8Array[] = [];
  let offset = 8 + 1;
  for (let i = 0; i < count && offset + 32 <= data.length; i++) {
    proofs.push(new Uint8Array(data.slice(offset, offset + 32)));
    offset += 32;
  }
  return proofs;
}

export function verifySignature(message: Uint8Array, signature: Uint8Array, pubkey: PublicKey): boolean {
  return nacl.sign.detached.verify(message, signature, pubkey.toBytes());
}
