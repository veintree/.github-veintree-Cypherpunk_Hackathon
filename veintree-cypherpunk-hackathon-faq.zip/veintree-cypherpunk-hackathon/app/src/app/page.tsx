'use client';
import { useEffect, useState } from 'react';
import { Connection, clusterApiUrl, PublicKey } from '@solana/web3.js';
const CLUSTER = process.env.NEXT_PUBLIC_SOLANA_CLUSTER || 'devnet';
const RPC_URL = process.env.NEXT_PUBLIC_SOLANA_RPC_URL || clusterApiUrl(CLUSTER as any);
import * as anchor from '@coral-xyz/anchor';
import { registerProof, registerProofAndIndex, verifyProof, listProofs, toProofHash, makeChallenge, verifySignature } from '../../../sdk/ts/src';

declare global { interface Window { solana?: any; } }

export default function Home() {
  const [connected, setConnected] = useState(false);
  const [pubkey, setPubkey] = useState<PublicKey | null>(null);
  const [status, setStatus] = useState<string>('');
  const [input, setInput] = useState<string>('my-vein-scan-sample');
  const [connection, setConnection] = useState<Connection | null>(null);
  const [proofs, setProofs] = useState<string[]>([]);

  useEffect(() => { setConnection(new Connection(RPC_URL, 'confirmed')); }, []);

  async function connectWallet() {
    if (!window.solana) { setStatus('Phantom not detected.'); return; }
    const resp = await window.solana.connect();
    setConnected(true);
    setPubkey(new PublicKey(resp.publicKey.toString()));
    setStatus('Wallet connected.');
  }

  function makeWallet(): anchor.Wallet {
    if (!window.solana) throw new Error('Phantom not available');
    return {
      publicKey: new PublicKey(window.solana.publicKey.toString()),
      signAllTransactions: window.solana.signAllTransactions,
      signTransaction: window.solana.signTransaction,
      signMessage: window.solana.signMessage,
      payer: undefined as any,
    } as unknown as anchor.Wallet;
  }

  async function onRegister() {
    if (!connection || !pubkey) return;
    setStatus('Registering proof (SHA3-256)...');
    const hash = toProofHash(input);
    const wallet = makeWallet();
    await registerProof(connection, wallet, hash);
    setStatus('Proof registered on-chain (per-user PDA) ✅');
  }

  async function onRegisterAndIndex() {
    if (!connection || !pubkey) return;
    setStatus('Registering proof + indexing...');
    const hash = toProofHash(input);
    const wallet = makeWallet();
    await registerProofAndIndex(connection, wallet, hash);
    setStatus('Proof registered + indexed ✅');
  }

  async function onVerify() {
    if (!connection || !pubkey) return;
    setStatus('Verifying proof...');
    const hash = toProofHash(input);
    const res = await verifyProof(connection, pubkey, hash);
    setStatus(res.exists ? (res.matches ? 'Proof matches ✅' : 'State exists, but mismatch ❌') : 'No state account on-chain ❌');
  }

  async function onListProofs() {
    if (!connection || !pubkey) return;
    setStatus('Reading index...');
    const arr = await listProofs(connection, pubkey);
    setProofs(arr.map((u8) => Buffer.from(u8).toString('hex')));
    setStatus('Index read ✅');
  }

  async function onServerVerify() {
    if (!pubkey || !window.solana) return;
    const msg = new TextEncoder().encode('veintree-challenge');
    const sig = await window.solana.signMessage(msg, 'utf8');
    const res = await fetch('/api/verify', {
      method: 'POST',
      headers: {'content-type':'application/json'},
      body: JSON.stringify({ message: Array.from(msg), signature: Array.from(sig.signature), pubkey: pubkey.toBase58() })
    }).then(r => r.json());
    setStatus(res.valid ? 'Server-side signature valid ✅' : 'Server-side signature invalid ❌');
  }

  return (
    <main style={{ padding: 24, fontFamily: 'system-ui, sans-serif' }}>
      <h1>Veintree — E2E (SHA3, Multi-user, Index, Server Verify)</h1>
      <div style={{ margin: '16px 0' }}>
        <button onClick={connectWallet} disabled={connected} style={{ padding: 8 }}>
          {connected ? 'Wallet Connected' : 'Connect Phantom Wallet'}
        </button>
        {pubkey && <p>Wallet: {pubkey.toBase58()}</p>}
      </div>

      <label>Input (mock vein scan): </label>
      <input value={input} onChange={(e) => setInput(e.target.value)} style={{ marginLeft: 8, padding: 6, minWidth: 260 }} />

      <div style={{ marginTop: 16, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <button onClick={onRegister} style={{ padding: 8 }}>Register Proof</button>
        <button onClick={onRegisterAndIndex} style={{ padding: 8 }}>Register + Index</button>
        <button onClick={onVerify} style={{ padding: 8 }}>Verify Proof</button>
        <button onClick={onListProofs} style={{ padding: 8 }}>List Proofs</button>
        <button onClick={onServerVerify} style={{ padding: 8 }}>Server Verify</button>
      </div>

      <p style={{ marginTop: 16 }}><strong>Status:</strong> {status}</p>

      {proofs.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <strong>Indexed proofs (hex):</strong>
          <ul>{proofs.map((h, i) => <li key={i}>{h}</li>)}</ul>
        </div>
      )}

      <hr style={{ margin: '24px 0' }} />
      <p><strong>Note:</strong> Deploy the on-chain program to <code>devnet</code> and ensure the program ID matches. Update <code>PROGRAM_ID</code> if needed.</p>
    </main>
  );
}
