
---

## 🐳 Docker (dev env)

```bash
# Build dev image (Node + Rust + Solana + Anchor)
docker compose build veintree-dev

# Start a shell in the dev container
docker compose run --rm veintree-dev bash

# Inside the container:
solana --version && anchor --version && node -v && cargo -V
./scripts/anchor-keys.sh
./scripts/anchor-deploy-devnet.sh
cd sdk/ts && npm run build
cd ../../app && npm run dev
```

> The dev service mounts your repo into `/workspace` and forwards port 3000.

---

## 🚀 Production Docker (Next.js)

```bash
# Build production image
docker compose build veintree-app-prod

# Run
docker compose up veintree-app-prod
# → http://localhost:3000
```

> The prod image builds the SDK first, then the Next.js app (standalone), and runs `next start` with production dependencies only.

### Notes
- Docker images now use **Node 20** (`node:20-bullseye`).
- Prod service exports `SOLANA_RPC_URL` and `NEXT_PUBLIC_SOLANA_CLUSTER` (defaults to devnet). Override via `docker compose run -e` or editing `docker-compose.yml`.
- Common commands available via **Makefile** (`make help`).

---

## 🔧 Environment (.env)

- Copy `.env.example` to `.env` (root) and `app/.env.example` to `app/.env` as needed.
- The app reads **client-side** vars:
  - `NEXT_PUBLIC_SOLANA_CLUSTER` (default: `devnet`)
  - `NEXT_PUBLIC_SOLANA_RPC_URL` (optional: overrides cluster URL)
- In Docker prod, `docker-compose.yml` sets:
  - `SOLANA_RPC_URL` and `NEXT_PUBLIC_SOLANA_CLUSTER` (propagate to app via build/run env).

Example:
```bash
cp .env.example .env
cp app/.env.example app/.env
# edit values, then:
make run-prod
```

See also **docs/FAQ.md** for common issues & fixes.
