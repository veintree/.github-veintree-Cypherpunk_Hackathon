'use client';
import { useEffect, useState } from 'react';
import { Connection, clusterApiUrl, PublicKey } from '@solana/web3.js';
import * as anchor from '@coral-xyz/anchor';
import { registerProof, verifyProof, toProofHash, makeChallenge, verifySignature } from '../../../sdk/ts/src';

declare global { interface Window { solana?: any; } }

export default function Home() {
  const [connected, setConnected] = useState(false);
  const [pubkey, setPubkey] = useState<PublicKey | null>(null);
  const [status, setStatus] = useState<string>('');
  const [input, setInput] = useState<string>('my-vein-scan-sample');
  const [connection, setConnection] = useState<Connection | null>(null);
  const [challenge, setChallenge] = useState<Uint8Array | null>(null);
  const [signatureOk, setSignatureOk] = useState<boolean | null>(null);

  useEffect(() => { setConnection(new Connection(clusterApiUrl('devnet'), 'confirmed')); }, []);

  async function connectWallet() {
    if (!window.solana) { setStatus('Phantom not detected.'); return; }
    const resp = await window.solana.connect();
    setConnected(true);
    setPubkey(new PublicKey(resp.publicKey.toString()));
    setStatus('Wallet connected.');
  }

  function makeWallet(): anchor.Wallet {
    if (!window.solana) throw new Error('Phantom not available');
    return {
      publicKey: new PublicKey(window.solana.publicKey.toString()),
      signAllTransactions: window.solana.signAllTransactions,
      signTransaction: window.solana.signTransaction,
      signMessage: window.solana.signMessage,
      payer: undefined as any,
    } as unknown as anchor.Wallet;
  }

  async function onRegister() {
    if (!connection || !pubkey) return;
    setStatus('Registering proof with SHA3-256...');
    const hash = toProofHash(input);
    const wallet = makeWallet();
    await registerProof(connection, wallet, hash);
    setStatus('Proof registered on-chain (per-user PDA) ✅');
  }

  async function onVerify() {
    if (!connection || !pubkey) return;
    setStatus('Verifying proof...');
    const hash = toProofHash(input);
    const res = await verifyProof(connection, pubkey, hash);
    setStatus(res.exists ? (res.matches ? 'Proof matches ✅' : 'State exists, but mismatch ❌') : 'No state account on-chain ❌');
  }

  async function onSignChallenge() {
    if (!pubkey || !window.solana) return;
    const ch = makeChallenge();
    setChallenge(ch);
    const sig = await window.solana.signMessage(ch, 'utf8');
    const ok = verifySignature(ch, new Uint8Array(sig.signature), pubkey);
    setSignatureOk(ok);
    setStatus(ok ? 'Challenge signed & verified ✅' : 'Signature verification failed ❌');
  }

  return (
    <main style={{ padding: 24, fontFamily: 'system-ui, sans-serif' }}>
      <h1>Veintree — End-to-End Demo (SHA3 + Multi-user PDA)</h1>
      <div style={{ margin: '16px 0' }}>
        <button onClick={connectWallet} disabled={connected} style={{ padding: 8 }}>
          {connected ? 'Wallet Connected' : 'Connect Phantom Wallet'}
        </button>
        {pubkey && <p>Wallet: {pubkey.toBase58()}</p>}
      </div>

      <label>Input (mock vein scan): </label>
      <input value={input} onChange={(e) => setInput(e.target.value)} style={{ marginLeft: 8, padding: 6, minWidth: 260 }} />

      <div style={{ marginTop: 16, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <button onClick={onRegister} style={{ padding: 8 }}>Register Proof</button>
        <button onClick={onVerify} style={{ padding: 8 }}>Verify Proof</button>
        <button onClick={onSignChallenge} style={{ padding: 8 }}>Sign Challenge</button>
      </div>

      <p style={{ marginTop: 16 }}><strong>Status:</strong> {status}</p>
      {signatureOk !== null && <p>Signature valid: {String(signatureOk)}</p>}

      <hr style={{ margin: '24px 0' }} />
      <p><strong>Note:</strong> Deploy the on-chain program to <code>devnet</code> and ensure the program ID matches. Update <code>PROGRAM_ID</code> if needed.</p>
    </main>
  );
}
