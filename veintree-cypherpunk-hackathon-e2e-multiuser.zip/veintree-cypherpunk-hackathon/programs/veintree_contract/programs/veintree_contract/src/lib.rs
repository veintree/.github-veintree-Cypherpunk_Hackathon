//! FR: Contrat de démonstration Veintree (POC) — multi-utilisateurs (PDA par wallet).
//! EN: Veintree demo contract (POC) — multi-user (PDA per wallet).

use anchor_lang::prelude::*;

declare_id!("VeinTree1111111111111111111111111111111111");

#[program]
pub mod veintree_contract {
    use super::*;

    /// FR: Enregistre le hash de preuve pour l'utilisateur (PDA dérivé du wallet).
    /// EN: Registers user's proof hash (PDA derived from wallet).
    pub fn register_proof(ctx: Context<RegisterProof>, proof_hash: [u8; 32]) -> Result<()> {
        let state = &mut ctx.accounts.state;
        state.last_proof = proof_hash;
        Ok(())
    }
}

#[derive(Accounts)]
#[instruction(proof_hash: [u8; 32])]
pub struct RegisterProof<'info> {
    /// FR: Compte d'état spécifique à l'utilisateur (seed = ["state", payer]).
    /// EN: Per-user state account (seed = ["state", payer]).
    #[account(
        init_if_needed,
        payer = payer,
        space = 8 + 32,
        seeds = [b"state", payer.key().as_ref()],
        bump
    )]
    pub state: Account<'info, State>,

    /// FR: Payeur / propriétaire de l'état.
    /// EN: Payer / state owner.
    #[account(mut)]
    pub payer: Signer<'info>,

    pub system_program: Program<'info, System>,
}

/// FR: État minimal contenant le dernier hash de preuve.
/// EN: Minimal state holding the last proof hash.
#[account]
pub struct State {
    pub last_proof: [u8; 32],
}
