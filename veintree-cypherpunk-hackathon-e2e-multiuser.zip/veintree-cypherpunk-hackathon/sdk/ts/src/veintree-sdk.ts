import { Connection, PublicKey } from "@solana/web3.js";
import * as anchor from "@coral-xyz/anchor";
import { sha3_256 } from "@noble/hashes/sha3";
import nacl from "tweetnacl";
import idl from "./idl/veintree_contract.json";

export const PROGRAM_ID = new PublicKey("VeinTree1111111111111111111111111111111111");
const STATE_SEED = "state";

// FR: PDA spécifique à l'utilisateur: seeds = ["state", userPubkey]
// EN: Per-user PDA: seeds = ["state", userPubkey]
export function getUserStatePda(user: PublicKey): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from(STATE_SEED), user.toBuffer()], PROGRAM_ID);
}

// FR: Hash SHA3-256 (32 octets).
// EN: SHA3-256 hash (32 bytes).
export function toProofHash(input: Uint8Array | string): Uint8Array {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  return new Uint8Array(sha3_256(bytes));
}

// FR: Challenge simple à signer par l'utilisateur.
// EN: Simple challenge to be signed by the user.
export function makeChallenge(): Uint8Array {
  const nonce = crypto.getRandomValues(new Uint8Array(16));
  const ts = new TextEncoder().encode(Date.now().toString());
  const payload = new Uint8Array(nonce.length + ts.length);
  payload.set(nonce, 0); payload.set(ts, nonce.length);
  return payload;
}

export function getProgram(connection: Connection, wallet: anchor.Wallet) {
  const provider = new anchor.AnchorProvider(connection, wallet, { commitment: "confirmed" });
  return new anchor.Program(idl as anchor.Idl, PROGRAM_ID, provider);
}

export async function registerProof(connection: Connection, wallet: anchor.Wallet, proofHash: Uint8Array) {
  const program = getProgram(connection, wallet);
  const [state] = getUserStatePda(wallet.publicKey);
  await program.methods
    .registerProof([...proofHash] as any)
    .accounts({ state, payer: wallet.publicKey, systemProgram: anchor.web3.SystemProgram.programId })
    .rpc();
  return state;
}

// FR: Vérifie la dernière preuve stockée pour un utilisateur donné.
// EN: Verifies the last stored proof for a given user.
export async function verifyProof(connection: Connection, user: PublicKey, proofHash: Uint8Array) {
  const [state] = getUserStatePda(user);
  const accountInfo = await connection.getAccountInfo(state);
  if (!accountInfo) return { exists: false, matches: false };
  const data = accountInfo.data;
  if (data.length < 8 + 32) return { exists: true, matches: false };
  const stored = data.slice(8, 8 + 32);
  const matches = stored.every((b, i) => b === proofHash[i]);
  return { exists: true, matches };
}

// FR: Vérifie une signature Ed25519 côté client.
// EN: Verifies an Ed25519 signature client-side.
export function verifySignature(message: Uint8Array, signature: Uint8Array, pubkey: PublicKey): boolean {
  return nacl.sign.detached.verify(message, signature, pubkey.toBytes());
}
