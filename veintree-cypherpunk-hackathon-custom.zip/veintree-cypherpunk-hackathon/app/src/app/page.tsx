export default function Home() {
  return (
    <main style={{ padding: 24, fontFamily: "system-ui, sans-serif" }}>
      <h1>Veintree — Cypherpunk Hackathon</h1>
      <p>FR: Démo client minimal. EN: Minimal client demo.</p>
      <ul>
        <li>No passwords. No databases. Just trust.</li>
        <li>Your veins, your key to digital life.</li>
        <li>Ethical identity. Post-quantum secure.</li>
      </ul>
    </main>
  );
}
