# 🎬 Veintree — Demo Guide (FR/EN)

## FR — Démo pas-à-pas (devnet)

1) **Préparer le wallet**  
```bash
./scripts/anchor-keys.sh
solana config set --url https://api.devnet.solana.com
solana airdrop 2
```

2) **Déployer le programme**  
```bash
./scripts/anchor-deploy-devnet.sh
# Si l'ID change, mettez-le dans: sdk/ts/src/veintree-sdk.ts (PROGRAM_ID)
```

3) **Installer et builder le SDK**  
```bash
cd sdk/ts && npm ci && npm run build
```

4) **Lancer l'app**  
```bash
cd ../../app && npm ci && npm run dev
# Ouvrez http://localhost:3000
# Connectez Phantom (réseau: devnet)
# - Register Proof: écrit un hash SHA3-256 dans le PDA utilisateur
# - Verify Proof: vérifie le hash on-chain
# - Register + Index: ajoute la preuve dans l'index utilisateur
# - List Proofs: liste les hashes de l'index
# - Server Verify: vérifie une signature côté serveur (API Next.js)
```

5) **(Optionnel) Peupler des données de démo**  
```bash
# Revenir à la racine du repo
cd ..
node scripts/seed-devnet.mjs "user-demo-1" "user-demo-2" "user-demo-3"
```

---

## EN — Step-by-step demo (devnet)

1) **Prepare wallet**  
```bash
./scripts/anchor-keys.sh
solana config set --url https://api.devnet.solana.com
solana airdrop 2
```

2) **Deploy program**  
```bash
./scripts/anchor-deploy-devnet.sh
# If program ID changes, update: sdk/ts/src/veintree-sdk.ts (PROGRAM_ID)
```

3) **Install & build SDK**  
```bash
cd sdk/ts && npm ci && npm run build
```

4) **Run the app**  
```bash
cd ../../app && npm ci && npm run dev
# Open http://localhost:3000, connect Phantom (devnet) and use the buttons.
```

5) **(Optional) Seed demo data**  
```bash
cd ..
node scripts/seed-devnet.mjs "user-demo-1" "user-demo-2" "user-demo-3"
```

### Notes
- No biometric data is stored — only a SHA3-256 hash and optional index entries.
- For real use, replace mock inputs with device-derived proofs and add liveness attestation.
