import { readFileSync } from 'fs';
import { homedir } from 'os';
import { join } from 'path';
import { Connection, clusterApiUrl, Keypair, PublicKey, SystemProgram } from '@solana/web3.js';
import * as anchor from '@coral-xyz/anchor';
import { toProofHash, registerProofAndIndex } from '../sdk/ts/dist/index.js';

function loadKeypair() {
  const p = process.env.SOLANA_WALLET || join(homedir(), '.config', 'solana', 'id.json');
  const arr = JSON.parse(readFileSync(p, 'utf-8'));
  const secretKey = Uint8Array.from(arr);
  return Keypair.fromSecretKey(secretKey);
}

function makeWallet(kp) {
  return {
    publicKey: kp.publicKey,
    async signTransaction(tx) { tx.partialSign(kp); return tx; },
    async signAllTransactions(txs) { txs.forEach(tx => tx.partialSign(kp)); return txs; },
  };
}

async function main() {
  const kp = loadKeypair();
  const wallet = makeWallet(kp);
  const connection = new Connection(clusterApiUrl('devnet'), 'confirmed');

  const inputs = process.argv.slice(2);
  if (inputs.length === 0) {
    console.log('Usage: node scripts/seed-devnet.mjs <demo1> <demo2> ...');
    process.exit(0);
  }

  for (const s of inputs) {
    const hash = toProofHash(s);
    await registerProofAndIndex(connection, wallet, hash);
    console.log(`Indexed proof for "${s}" (wallet ${wallet.publicKey.toBase58()})`);
  }

  console.log('Done.');
}

main().catch((e) => { console.error(e); process.exit(1); });
